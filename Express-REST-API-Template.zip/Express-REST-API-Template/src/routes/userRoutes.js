const express = require('express');

const router = express.Router();

const userController = require('../controllers/userController');

router.get('/', (req, res) => {
  res.send({ message: 'Hello world' });
});
router.get('/users', userController.getUsers);
router.get('/users/search', userController.searchUsers);
router.get('/users/sort', userController.sortUsers);
router.get('/users/filter', userController.filterUsers);
router.get('/users/paginate', userController.paginateUsers);
module.exports = router;

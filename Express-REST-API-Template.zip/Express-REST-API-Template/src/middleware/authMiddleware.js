const secretKey = process.env.SECRET_KEY || 'rajesh-secret-key';

const authenticate = (req, res, next) => {
  const token = req.headers.authorization;
  if (token === secretKey) {
    next();
  } else {
    res.status(401).json({ message: 'Unauthorized' });
  }
};

module.exports = authenticate;

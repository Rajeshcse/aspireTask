const express = require('express');
const createError = require('http-errors');
const cookieParser = require('cookie-parser');
const authenticate = require('./middleware/authMiddleware');
const userRoutes = require('../src/routes/userRoutes');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

require('dotenv').config();

app.use('/api', authenticate, userRoutes);

app.use((req, res, next) => {
  next(createError.NotFound());
});

require('dotenv').config();

module.exports = app;

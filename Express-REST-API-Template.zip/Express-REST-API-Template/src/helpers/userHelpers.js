/* eslint-disable no-nested-ternary */
// Helper function to sanitize user data
const sanitizeUser = (user) => {
  const {
    id,
    firstName,
    lastName,
    username,
    role,
    email,
    phone,
    image,
    gender,
  } = user;
  return {
    id,
    firstName,
    lastName,
    username,
    role,
    email,
    phone,
    image,
    gender,
  };
};

// Helper function to get sanitized and optionally sorted user data
const getSanitizedUsers = (users) => {
  return users.map(sanitizeUser);
};

// Helper function to sort users
const sortUsersHelper = (users, sortBy, order) => {
  return users.sort((a, b) => {
    const compareA =
      typeof a[sortBy] === 'string' ? a[sortBy].toLowerCase() : a[sortBy];
    const compareB =
      typeof b[sortBy] === 'string' ? b[sortBy].toLowerCase() : b[sortBy];
    if (order === 'asc') {
      return compareA > compareB ? 1 : compareA < compareB ? -1 : 0;
      // eslint-disable-next-line no-else-return
    } else {
      return compareA < compareB ? 1 : compareA > compareB ? -1 : 0;
    }
  });
};

module.exports = {
  sanitizeUser,
  getSanitizedUsers,
  sortUsersHelper,
};

// src/controllers/userController.js
/* eslint-disable consistent-return */
/* eslint-disable no-nested-ternary */
/* eslint-disable no-else-return */
const data = require('../../data.json');
const {
  getSanitizedUsers,
  sortUsersHelper,
} = require('../helpers/userHelpers');
const redisClient = require('../helpers/redisClient');

const CACHE_KEY = 'users_data';
const CACHE_EXPIRATION = 60;

const getData = async () => {
  const cachedData = await redisClient.get(CACHE_KEY);
  if (cachedData) {
    return JSON.parse(cachedData);
  }
  const freshData = data.users;
  await redisClient.setEx(
    CACHE_KEY,
    CACHE_EXPIRATION,
    JSON.stringify(freshData),
  );
  return freshData;
};

exports.getUsers = async (req, res) => {
  try {
    const users = await getSanitizedUsers(await getData()); // Return only the non-sensitive fields
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching users', error });
  }
};

exports.searchUsers = async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) {
      return res
        .status(400)
        .json({ message: 'Query parameter q is required for searching.' });
    }
    const queryLower = q.toLowerCase();
    const users = getSanitizedUsers(
      (await getData()).filter(
        (user) =>
          user.firstName.toLowerCase().includes(queryLower) ||
          user.lastName.toLowerCase().includes(queryLower) ||
          user.username.toLowerCase().includes(queryLower),
      ),
    );
    if (users.length === 0) {
      return res
        .status(404)
        .json({ message: 'No users found matching the search criteria.' });
    }
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error searching users', error });
  }
};

exports.sortUsers = async (req, res) => {
  try {
    const { sortBy = 'firstName', order = 'asc' } = req.query;
    const users = getSanitizedUsers(
      sortUsersHelper(await getData(), sortBy, order),
    );
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error sorting users', error });
  }
};

exports.filterUsers = async (req, res) => {
  try {
    const filters = req.query;

    const users = getSanitizedUsers(
      (await getData()).filter((user) =>
        Object.keys(filters).every((filterKey) => {
          const filterValue = filters[filterKey].toLowerCase();
          const userValue = String(user[filterKey]).toLowerCase();
          return userValue === filterValue;
        }),
      ),
    );

    if (users.length === 0) {
      return res
        .status(404)
        .json({ message: 'No users found matching the filter criteria.' });
    }
    const sanitizedUsers = getSanitizedUsers(users);
    res.json(sanitizedUsers);
  } catch (error) {
    res.status(500).json({ message: 'Error filtering users', error });
  }
};

exports.paginateUsers = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const pageNumber = parseInt(page, 10);
    const limitNumber = parseInt(limit, 10);
    const allUsers = await getData();
    const totalUsers = allUsers.length;
    const totalPages = Math.ceil(totalUsers / limitNumber);
    const users = getSanitizedUsers(
      allUsers.slice((pageNumber - 1) * limitNumber, pageNumber * limitNumber),
    );

    res.json({
      page: pageNumber,
      limit: limitNumber,
      totalUsers,
      totalPages,
      users,
    });
  } catch (error) {
    res.status(500).json({ message: 'Error paginating users', error });
  }
};
